// 

const article = require('./article.json')

module.exports = function() {
    return {
        article,
    }
}